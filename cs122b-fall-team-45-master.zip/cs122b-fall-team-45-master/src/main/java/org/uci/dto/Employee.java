package org.uci.dto;

public class Employee {
    private final String name;

    public String getName() {
        return name;
    }

    public Employee(String name) {
        this.name = name;
    }
}
